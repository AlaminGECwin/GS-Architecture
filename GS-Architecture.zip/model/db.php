<?php
class Database{

	function __construct()
	{
		# code...

	}
	private $host;
	private $dbusername;
	private $dbpassword;
	private $dbname;

	private function online(){
		$this->host='localhost';
		$this->dbusername='generics_gs';
		$this->dbpassword='54213;.,HbD+';
		$this->dbname='generics_gs';
		try{
			$connection=new PDO("mysql:host=$this->host;dbname=$this->dbname",$this->dbusername,$this->dbpassword);

		}catch(PDOExection $e){
			echo $e->getMessage();
		}
		return $connection;
	}
	private function offline(){
		$this->host='localhost';
		$this->dbusername='root';
		$this->dbpassword='';
		$this->dbname='gs_database';
		try{
			$connection=new PDO("mysql:host=$this->host;dbname=$this->dbname",$this->dbusername,$this->dbpassword);

		}catch(PDOExection $e){
			echo $e->getMessage();
		}
		return $connection;
	}

	protected function connect(){
		$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$word="localhost";
		//echo $actual_link;
		if(strpos($actual_link, $word) !== false){
			return $this->offline();
		} else{
			return $this->online();
		}



	}


}

class GS_Model extends Database{
	function __construct(){
		

	}
	function execute_query($sql){
		$database=new Database();
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
	}
	function read_query($sql){
		$database=new Database();
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
		$data=$stmt->fetchAll(PDO::FETCH_ASSOC);
		return $data;
	}



	function insert_student_registration_information($full_name,$student_id,$email,$password,$birth_year,$birth_month,$birth_date,$gender,$mobile,$year,$class,$department,$roll){
		$database=new Database();
		$sql="INSERT INTO `student_registration` (`id`,`full_name`, `student_id`, `email`, `password`, `birth_year`, `birth_month`, `birth_date`, `gender`, `mobile`, `year`, `class`, `department`, `roll`) VALUES (NULL, '$full_name', '$student_id', '$email', '$password', '$birth_year', '$birth_month', '$birth_date', '$gender', '$mobile', '$year', '$class', '$department', '$roll')";
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
		//echo $sql;
	}
	
	function get_number_of_student(){
	    $database=new Database();
		$sql="SELECT COUNT(id) FROM `student_registration`";
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
		$data=$stmt->fetchAll(PDO::FETCH_ASSOC);
		//echo $sql;
		return $data[0]['COUNT(id)'];
	}
	function get_number_of_student_in_year($year){
	    $database=new Database();
		$sql="SELECT COUNT(id) FROM `student_registration` where year='$year'";
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
		$data=$stmt->fetchAll(PDO::FETCH_ASSOC);
		//echo $sql;
		return $data[0]['COUNT(id)'];
	}

	function get_number_of_student_in_class($class){
	    $database=new Database();
		$sql="SELECT COUNT(id) FROM `student_registration` where class=$class";
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
		$data=$stmt->fetchAll(PDO::FETCH_ASSOC);
		//echo $sql;
		return $data[0]['COUNT(id)'];
	}

	function insert_subject($subject_name){
		$database=new Database();
		$sql="INSERT INTO `subject` (`id`, `name`) VALUES (NULL, '$subject_name')";
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
	}
	function insert_sutdent_4th_subject($st_id,$subject_in_class_id){
		$database=new Database();
		$sql="INSERT INTO `student_4th_subject` (`id`, `subject_in_class_id`, `student_id`) VALUES (NULL, '$subject_in_class_id','$st_id')";
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
	}
	
	function update_mark($id,$mark){
		$database=new Database();
		$sql="UPDATE  student_result SET `mark`='$mark' where id='$id'";
		$stmt=$database->connect()->prepare($sql);
		$stmt->execute();
	}

}
?>
